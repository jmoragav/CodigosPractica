<?php


header('Location: ' . "./reporte_silos.php");
die();


?>
<?php
	$id=$_GET['id'];

	$serverName = "NEP-DC-F02"; 


$username ="practica";
$password ="practica";
$database ="SilosPractica";



$conn = mssql_connect($serverName, $username, $password);




$stmt = mssql_init('[dbo].[pkg_Silo.ChangeStateSilo]');


mssql_bind($stmt, '@IdSilo',   $id,   SQLINT4 ,false,false,4);
$result=mssql_execute($stmt);













?>
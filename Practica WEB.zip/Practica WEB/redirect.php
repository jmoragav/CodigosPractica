<?php

$url=$_GET["url"];


header('Location: ' . $url);
die();


?>
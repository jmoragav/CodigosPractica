$(document).ready(function(){
   $("form#forma").submit();
});
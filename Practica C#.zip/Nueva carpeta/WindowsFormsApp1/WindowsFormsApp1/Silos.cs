﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Windows.Forms;

namespace WindowsFormsApp1
{



    public partial class Silos : Form
    {


        public SqlConnection cnn;
        private SqlDataAdapter adapter;
        DataTable dataTable = new DataTable();
        private bool loged;
        private bool first_time;
        DataGridViewImageColumn iconColumn;

        public Silos()
        {
            InitializeComponent();
            loged = false;
            first_time = true;
        }


        public Silos(bool bo)
        {
            InitializeComponent();
            loged = bo;
            first_time = true;
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void InitDB() {

        string connetionString = @"Data Source=NEP-DC-F02;Initial Catalog=SilosPractica ;User ID=practica;Password=practica";
        cnn = new SqlConnection(connetionString);

            cnn.Open();
            SqlCommand command_0;
            SqlDataReader datar_0;
            SqlCommand command_1;
            SqlDataReader datar_1;
            String sql;




            sql = "SELECT id_dispositivo,modelo FROM Dispositivo WHERE estado LIKE 'activo%'";
            command_1 = new SqlCommand(sql, cnn);

            datar_1 = command_1.ExecuteReader();


            dispositivo.Items.Clear();
            while (datar_1.Read())
            {
                string mod_id = datar_1.GetValue(0) + "-" + datar_1.GetValue(1);
                dispositivo.Items.Add(mod_id);


            }
            cnn.Close();
            cnn.Open();
            sql = "SELECT username FROM Usuario WHERE estado LIKE 'activo%' ";
            command_0 = new SqlCommand(sql, cnn);

            datar_0 = command_0.ExecuteReader();


            user.Items.Clear();
            while (datar_0.Read())
            {

                user.Items.Add(datar_0.GetValue(0));


            }






            cnn.Close();

        }
        private void Form3_Load(object sender, EventArgs e)
        {
            
            

        }

        private void Form3_Shown(object sender, EventArgs e)
        {

            InitDB();
            if (loged)
            {
                permiso.Text = "Activo";
            }
            ShowDB();


        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            if (loged)
            {
                String nombre = txtName.Text;
                String ubicacion = txtUB.Text;
                String minimo = txtMin.Text;
                String maximo = txtMax.Text;



                ValidadorSilos valid = new ValidadorSilos(nombre, ubicacion, maximo, minimo);
                List<Object> l = valid.validar();
                int last = l.Count;
                bool checkeo = (bool)l.ElementAt(last - 1);

                if (checkeo)
                {
                    try
                    {

                        cnn.Open();
                        SqlCommand command;
                        SqlDataAdapter adapter = new SqlDataAdapter();
                        String sql;

                        SqlCommand comm;
                        SqlDataReader datar;
                        String sql_sel_id_usr;

                        sql_sel_id_usr = "SELECT id_usuario FROM Usuario WHERE username='" + user.Text + "'";
                        comm = new SqlCommand(sql_sel_id_usr, cnn);



                        datar = comm.ExecuteReader();
                        datar.Read();
                        int id_user = (int)datar.GetValue(0);

                        String[] dummy = dispositivo.Text.Split('-');

                        string id_disp = dummy[0];


                        cnn.Close();
                        cnn.Open();


                        string values = '(' + "'" + txtName.Text + "'," + "'" + txtUB.Text + "'," + "'" + desc.Text + "'," + "'" + txtMin.Text + "'," + "'" + txtMax.Text + "'," + "'" + id_disp + "'," + "'" + id_user.ToString() + "'," + "'"+Estado.Text + "')";
                        sql = "INSERT INTO Silo (nombre, ubicacion, descripcion,minimo,maximo,id_dispositivo,id_usuario,estado) VALUES" + values;

                        command = new SqlCommand(sql, cnn);

                        adapter.InsertCommand = new SqlCommand(sql, cnn);
                        adapter.InsertCommand.ExecuteNonQuery();

                        command.Dispose();
                        cnn.Close();
                        ShowDB();
                        MessageBox.Show("Se registro de manera exitosa el Silo", "Registrado",
                          MessageBoxButtons.OK, MessageBoxIcon.Information);

                    }

                    catch (SqlException ex)
                    {

                        StringBuilder errorMessages = new StringBuilder();
                        for (int i = 0; i < ex.Errors.Count; i++)
                        {
                            errorMessages.Append("Index #" + i + "\n" +
                                "Message: " + ex.Errors[i].Message + "\n" +
                                "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                                "Source: " + ex.Errors[i].Source + "\n" +
                                "Procedure: " + ex.Errors[i].Procedure + "\n");
                        }

                        MessageBox.Show(errorMessages.ToString(), "Errores con la base de datos",
                          MessageBoxButtons.OK, MessageBoxIcon.Exclamation);


                    }

                    catch (Exception ewe)
                    {


                        MessageBox.Show(ewe.ToString(), "Error",
                              MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }

                }

                else
                {


                    string error = "";


                    for (int k = 0; k < (l.Count - 1); k++)
                    {

                        error = error + l.ElementAt(k) + '\n';

                    }
                    MessageBox.Show(error, "Errores de validacion",
                              MessageBoxButtons.OK, MessageBoxIcon.Exclamation);


                }

            }
            else {

                MessageBox.Show("Debe iniciar sesion para poder ingresar un Silo", "Errores de permisos",
                         MessageBoxButtons.OK, MessageBoxIcon.Error);


            }

        }

        private void user_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void dispositivo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void estado_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void ShowDB()
        {


            if (loged)
            {
                griddisp.DataSource = null;
                dataTable.Clear();
                cnn.Open();
                DataSet dataset = new DataSet("Silo");
                String queryString = "SELECT * FROM Silo WHERE estado LIKE 'Activo%'";
                adapter = new SqlDataAdapter();
                adapter.SelectCommand = new SqlCommand(
                    queryString, cnn);
                adapter.Fill(dataset);
                dataTable = dataset.Tables[0];
                BindingSource bindingSource = new BindingSource { DataSource = dataTable };

                griddisp.DataSource = bindingSource;
         
                griddisp.Columns["id_silo"].Visible = false;
                griddisp.Columns["id_dispositivo"].Visible = false;
                griddisp.Columns["id_usuario"].Visible = false;

                cnn.Close();
                
                if (first_time)
                {
                    iconColumn = new DataGridViewImageColumn();
                    iconColumn.Image = Properties.Resources.equis;
                    iconColumn.Name = "Eliminar";
                    iconColumn.HeaderText = "Eliminar";
                    griddisp.Columns.Insert(9, iconColumn);
                    first_time = false;
                }

                griddisp.Columns["Eliminar"].DisplayIndex = 9;



            }

            else
            {

                griddisp.ReadOnly = true;
                griddisp.AllowUserToDeleteRows = false;

                griddisp.DataSource = null;
                dataTable.Clear();
                cnn.Open();
                DataSet dataset = new DataSet("Silo");
                String queryString = "SELECT * FROM Silo WHERE estado Like 'activo%' ";


                adapter = new SqlDataAdapter();
                adapter.SelectCommand = new SqlCommand(
                    queryString, cnn);
                adapter.Fill(dataset);
                dataTable = dataset.Tables[0];
                BindingSource bindingSource = new BindingSource { DataSource = dataTable };

                griddisp.DataSource = bindingSource;
 
                griddisp.Columns["id_silo"].Visible = false;
                griddisp.Columns["id_dispositivo"].Visible = false;
                griddisp.Columns["id_usuario"].Visible = false;


                cnn.Close();

            }
        }




        private void griddisp_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = (DataGridViewRow)griddisp.Rows[e.RowIndex];
            String nombre = (String)row.Cells["nombre"].Value;
            String ubc = (String)row.Cells["ubicacion"].Value;
            String desc = (String)row.Cells["descripcion"].Value;
            String esta = (String)row.Cells["estado"].Value;
            int min = (Int32)row.Cells["minimo"].Value;
            int max = (Int32)row.Cells["maximo"].Value;
            int id_user = (Int32)row.Cells["id_usuario"].Value;
            int id_disp = (Int32)row.Cells["id_dispositivo"].Value;
            int id_silo = (Int32)row.Cells["id_silo"].Value;


            SqlCommand cmd = new SqlCommand("[dbo].[pkg_Silo.UpdateSilo]", cnn);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(
                    new SqlParameter("@IdSilo", id_silo));
            cmd.Parameters.Add(
           new SqlParameter("@IdUsuario", id_user));
            cmd.Parameters.Add(
           new SqlParameter("@IdDispositivo", id_disp));
            cmd.Parameters.Add(
           new SqlParameter("@Maximo", max));
            cmd.Parameters.Add(
           new SqlParameter("@Ubicacion", ubc));
            cmd.Parameters.Add(
           new SqlParameter("@Minimo", min));
            cmd.Parameters.Add(
           new SqlParameter("@Nombre", nombre));
            cmd.Parameters.Add(
           new SqlParameter("@Descripcion", desc));
            cmd.Parameters.Add(
           new SqlParameter("@Estado", esta));


            cnn.Open();
            cmd.ExecuteNonQuery();
            cnn.Close();

            MessageBox.Show("Se actualizo la informacion", "Modificacion",
             MessageBoxButtons.OK, MessageBoxIcon.Information);
        }




        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click_1(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Estado_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void griddisp_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void griddisp_CellDoubleClick(object sender, DataGridViewCellEventArgs e) {
            
            if (e.ColumnIndex == iconColumn.Index) {



                DialogResult dr = MessageBox.Show("Esta apunto de cambiar el estado ¿Desea Continuar?", "Confirmación", MessageBoxButtons.YesNoCancel,
       MessageBoxIcon.Information);

                if (dr == DialogResult.Yes)
                {
                    DataGridViewRow row = griddisp.Rows[e.RowIndex];

                    int id = (Int32)row.Cells["id_silo"].Value;

                    SqlCommand cmd = new SqlCommand("[dbo].[pkg_Silo.ChangeStateSilo]", cnn);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(
                            new SqlParameter("@IdSilo", id));


                    cnn.Open();
                    cmd.ExecuteNonQuery();
                    cnn.Close();
                    griddisp.Rows.RemoveAt(e.RowIndex);
                }
            }

        }
    }





        
    }

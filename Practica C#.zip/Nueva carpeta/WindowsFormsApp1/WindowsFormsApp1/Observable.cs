﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    interface Observable 
    {

        void notifyObservers();
        void addObservers(Observers_Login waiter);
        DialogResult ShowDialog();

    }
}

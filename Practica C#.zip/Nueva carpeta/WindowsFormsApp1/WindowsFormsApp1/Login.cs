﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Login : Form, Observable
    {
        public SqlConnection cnn;
        private List<Observers_Login> waiters;

        public Login()
        {
            InitializeComponent();
            waiters = new List<Observers_Login>(); 

        }

       private void InitDB()
        {

            string connetionString = @"Data Source=NEP-DC-F02;Initial Catalog=SilosPractica ;User ID=practica;Password=practica";
            cnn = new SqlConnection(connetionString);

        }

       private void groupBox1_Enter(object sender, EventArgs e)
       {

        }

        private void Usuario_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            InitDB();
            txtPass.PasswordChar = '*';
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String user = txtUser.Text;
            String pass = txtPass.Text;




            bool registered = userIndb(user);

            if (registered)
            {


                cnn.Open();
                SqlCommand command_0;
                SqlDataReader datar_0;
                String sql;

                sql = "SELECT password FROM Usuario WHERE username='" + user + "'"+"and password='"+pass+"'";
                command_0 = new SqlCommand(sql, cnn);

                datar_0 = command_0.ExecuteReader();
                
               
                
                if (!datar_0.Read())
                {


                    MessageBox.Show("La contraseña ingresada no se encuentra asociada a el usuario", "Problemas de inicio",
                      MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    cnn.Close();
                }

                else
                {

                    MessageBox.Show("Sesion iniciada con exito", "Bienvenido",
                      MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.notifyObservers();
                    this.Close();
                    
                }

            }


            else
            {

                MessageBox.Show("El usuario ingresado no se encuentra dentro de los registros", "Problemas de inicio",
                      MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }



        }

        private bool userIndb(string user)
        {
            cnn.Open();
            SqlCommand command_0;
            SqlDataReader datar_0;
            String sql;

            sql = "SELECT username FROM Usuario WHERE username='"+user+"'";
            command_0 = new SqlCommand(sql, cnn);

            datar_0 = command_0.ExecuteReader();
            if (!datar_0.Read()) {


                
                cnn.Close();
                return false;
            }

            else
            {

                
                cnn.Close();

                return true;
            }

            


        }


        

        public void notifyObservers()
        {
            foreach (Observers_Login waiter in waiters)
            {

                waiter.Logear();
            }
        }

        public void addObservers(Observers_Login waiter)
        {
            waiters.Add(waiter);
        }

    }
}

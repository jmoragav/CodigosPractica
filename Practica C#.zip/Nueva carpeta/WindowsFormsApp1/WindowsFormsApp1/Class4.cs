﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    class ValidadorRegist

    {



        private string nombre;
        private string apellido;
        private string username;
        private string password;
        private string email;

        public ValidadorRegist(String Nombre, String Apellido, string Username, string Password, string Email)
        {

            nombre = Nombre;
            apellido = Apellido;
            username = Username;
            password = Password;
            email = Email;

        }

        public List<Object> validar()
        {
            bool final = true;
            String nombre_err = "";
            String apellido_err = "";
            String usr_err= "";
            String password_err = "";
            String email_err = "";
            String regex_nomub = @"^[a-zA-Z0-9&._-]+$";
            String regex_nombre = @"^[a-zA-Z.-]+$";
        

            List<Object> add_list = new List<object>();


            if (Regex.IsMatch(nombre, regex_nombre))
            {

                final = true && final;

            }

            else
            {

                nombre_err = "Su nombre contiene algun caracter no valido";

                add_list.Add(nombre_err);
                final = false;
            }



            if (Regex.IsMatch(apellido, regex_nomub) || String.IsNullOrEmpty(apellido))
            {

                final = true && final;

            }

            else
            {

                apellido_err = "El apellido entregado contiene algun caracter no valido";

                add_list.Add(apellido_err);
                final = false;
            }





            if (Regex.IsMatch(username, regex_nomub))
            {

                final = true && final;

            }

            else
            {

                usr_err = "Su nombre de usuario conitene algun caracter no valido";

                add_list.Add(usr_err);
                final = false;
            }

            if (Regex.IsMatch(password, regex_nomub))
            {

                final = true && final;

            }

            else
            {

                password_err = "La contraseña entregada contiene algun caracter no valido";

                add_list.Add(password_err);
                final = false;
            }

            if (IsValid(email))
            {


                final = true && final;

            }

            else {

                email_err = "El email entregado no cumple con el formato adecuado";

                add_list.Add(email_err);
                final = false;

            }



            add_list.Add(final);

            return add_list;

        }


        public bool IsValid(string emailaddress)
        {
            try
            {
                MailAddress m = new MailAddress(emailaddress);

                return true;
            }
            catch (FormatException)
            {
                return false;
            }
            catch (ArgumentException) {

                return false;
            }

        }

    }
}

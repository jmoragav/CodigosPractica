﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Registro : Form
    {
        private SqlConnection cnn;


        public Registro()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String nombre = txtname.Text;
            String apellido = txtapellido.Text;
            String correo = txtMail.Text;
            String username = txtusername.Text;
            String pass = txtpassword.Text;


            ValidadorRegist valid = new ValidadorRegist(nombre, apellido, username, pass, correo);

            List<Object> l = valid.validar();
            int last = l.Count;
            bool checkeo = (bool)l.ElementAt(last - 1);

            if (checkeo)
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("[dbo].[pkg_Usuario.Registrar]", cnn);

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(
                            new SqlParameter("@Nombre", nombre));
                    cmd.Parameters.Add(
                              new SqlParameter("@Apellido", apellido));
                    cmd.Parameters.Add(
                                new SqlParameter("@Correo", correo));

                    cmd.Parameters.Add(
                                   new SqlParameter("@Username", username));

                    cmd.Parameters.Add(
                                    new SqlParameter("@Password", pass));

                    cmd.Parameters.Add(
                                    new SqlParameter("@Estado", "Activo"));



                    cnn.Open();
                    cmd.ExecuteNonQuery();
                    cnn.Close();



                    MessageBox.Show("Se registro de manera exitosa", "Registrado",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

                    this.Close();
                }


                catch (SqlException ex)
                {

                    StringBuilder errorMessages = new StringBuilder();
                    for (int i = 0; i < ex.Errors.Count; i++)
                    {
                        errorMessages.Append("Index #" + i + "\n" +
                            "Message: " + ex.Errors[i].Message + "\n" +
                            "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                            "Source: " + ex.Errors[i].Source + "\n" +
                            "Procedure: " + ex.Errors[i].Procedure + "\n");
                    }

                    MessageBox.Show(errorMessages.ToString(), "Errores con la base de datos",
                      MessageBoxButtons.OK, MessageBoxIcon.Exclamation);


                }
            }


            else {

                string error = "";


                for (int k = 0; k < (l.Count - 1); k++)
                {

                    error = error + l.ElementAt(k) + '\n';

                }
                MessageBox.Show(error, "Errores de validacion",
                          MessageBoxButtons.OK, MessageBoxIcon.Exclamation);


            }


                 }

        private void Form1_Load(object sender, EventArgs e)
        {
            string connetionString;

            connetionString = @"Data Source=NEP-DC-F02;Initial Catalog=SilosPractica ;User ID=practica;Password=practica";
            cnn = new SqlConnection(connetionString);

        }
    }
}

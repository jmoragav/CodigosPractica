﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace WindowsFormsApp1
{
    class Validator
    {
        private string ip;
        private string port;
        private string modbus;
        private int machinetype;


        //machinetype 0 = ADAM 1 = USR
        public Validator (String ipe, String puerto, String mod, int machine)
        {
            ip = ipe;
            port = puerto;
            modbus = mod;
            machinetype = machine;
        }



        public List<Object> validar()
        {
            bool final = true;
            String port_err = "";
            String ip_err = "";
            String mod_err = "";

            List<Object> add_list = new List<object>();


            if (Regex.IsMatch(port, @"^\d+$"))
            {

                final = true && final;

            }

            else
            {

                port_err = "El puerto entregado no es valido, revise si uso un puerto numerico";

                add_list.Add(port_err);
                final = false;
            }

            if (IsValidateIP(ip))
            {

                final = true && final;


            }


            else
            {
                ip_err = "El ip entregado no es valido";
                final = false;
                add_list.Add(ip_err);
            }

            if (machinetype == 0)
            {

                String patron_separado = @"(([A-Z0-9]){2} *){12}";
                String patron_junto = @"([A-Z0-9]){24}";

                Match m = Regex.Match(modbus, patron_separado);
                Match m2 = Regex.Match(modbus, patron_junto);
                if (m.Success && modbus.Length == 35)
                {

                    final = true && final;


                }

                else if (m2.Success && modbus.Length == 24)
                {

                    final = true && final;


                }

                else
                {

                    mod_err = "El comando ingreso no cumple con el formato adecuado" + '\n' + "Los formatos adecuados son los siguientes" + '\n' + "XX XX XX XX ..... " + '\n' + "XXXXXXXX ..... "
                        + '\n' + "Cada comando debe estar compuesto por 12 bytes";

                    add_list.Add(mod_err);
                    final = false;
                }

            }

            else if (machinetype == 1)
            {


                String patron_separado = @"(([A-Z0-9]){2} *){8}";
                String patron_junto = @"([A-Z0-9]){16}";
                Match m = Regex.Match(modbus, patron_separado);
                Match m2 = Regex.Match(modbus, patron_junto);
                if (m.Success && modbus.Length == 23)
                {

                    final = true && final;

                }

                else if (m2.Success && modbus.Length == 16)
                {


                    final = true && final;


                }


                else
                {

                    mod_err = "El comando ingreso no cumple con el formato adecuado" + '\n' + "Los formatos adecuados son los siguientes" + '\n' + "XX XX XX XX ..... " + '\n' + "XXXXXXXX ..... "
                        + '\n' + "Cada comando debe estar compuesto por 8 bytes";


                    add_list.Add(mod_err);
                    final = false;
                }

            }

            add_list.Add(final);

            return add_list;

        }




        public static bool IsValidateIP(string Address)
        {
            //Match pattern for IP address    
            string Pattern = @"^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$";
            //Regular Expression object    
            Regex check = new Regex(Pattern);

            //check to make sure an ip address was provided    
            if (string.IsNullOrEmpty(Address))
                //returns false if IP is not provided    
                return false;
            else
                //Matching the pattern    
                return check.IsMatch(Address, 0);
        }

    }
}

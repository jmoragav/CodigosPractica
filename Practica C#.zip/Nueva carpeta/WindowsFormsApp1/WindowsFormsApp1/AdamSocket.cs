﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;


public class AdamSocket 
{
    public Socket RealSocket { get; }

    private int puerto;
   

    public IPAddress Ipadress { get; }
    
    public byte[] respuesta { get; }

    private int numdatos;

    public int Numdatos { get { return numdatos; } set { numdatos = value; } }



    public AdamSocket(String ip, int port)
    {
         RealSocket = new Socket(IPAddress.Parse(ip).AddressFamily,
                SocketType.Stream, ProtocolType.Tcp);

        puerto = port;
        Ipadress = IPAddress.Parse(ip);
        respuesta = new byte[1024];
        numdatos = 0;
    }



    public void connect()
    {


        IPEndPoint remoteEP = new IPEndPoint(Ipadress, puerto);
        try
        {
            // Connect to Remote EndPoint  
            RealSocket.Connect(remoteEP);
        }

        catch (ArgumentNullException ane)
        {
            Console.WriteLine("ArgumentNullException : {0}", ane.ToString());
        }
        catch (SocketException se)
        {
            Console.WriteLine("SocketException : {0}", se.ToString());
        }
        catch (Exception e)
        {
            Console.WriteLine("Unexpected exception : {0}", e.ToString());
        }




    }

    public static byte[] FormarModbus(String mensaje)
    {
        string[] valores = mensaje.Split(' ');
        byte[] frame = new byte[12];
        int largo = valores.Length;
      
        
        for (int i = 0; i < largo; i++)
        {
            int numin = int.Parse(valores[i], System.Globalization.NumberStyles.HexNumber);
            String dummy = numin.ToString();
            frame[i] = Convert.ToByte(dummy);
          
        }
       
    
        return frame;

    }

    

    public void SendData(String mensaje) {
        byte[] msg = FormarModbus(mensaje);
        int bytesSent = RealSocket.Send(msg); 
    }


    public void ReciveData() {

        int bytesRec = RealSocket.Receive(respuesta);
        numdatos = bytesRec;
        byte[] dummy = new byte[bytesRec];
        Array.Copy(respuesta, 0, dummy, 0, bytesRec);
        Array.Copy(dummy, 0, respuesta, 0, bytesRec);

        RealSocket.Shutdown(SocketShutdown.Both);
        RealSocket.Close();
    }





}

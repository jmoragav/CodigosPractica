﻿namespace WindowsFormsApp1
{
    partial class Control
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Control));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxADAM = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txtModADAM = new System.Windows.Forms.TextBox();
            this.ADAMBUTTON = new System.Windows.Forms.Button();
            this.txtPuertoADAM = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtIpADAM = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBoxUSRDR302 = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.txtUSRmod = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtUSRIp = new System.Windows.Forms.TextBox();
            this.txtUSRport = new System.Windows.Forms.TextBox();
            this.USRDRBUTTON = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.outputADAM = new System.Windows.Forms.RichTextBox();
            this.outputUSR = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.barracontrol = new System.Windows.Forms.MenuStrip();
            this.visyedit = new System.Windows.Forms.ToolStripMenuItem();
            this.dispositivos = new System.Windows.Forms.ToolStripMenuItem();
            this.silos = new System.Windows.Forms.ToolStripMenuItem();
            this.login = new System.Windows.Forms.ToolStripMenuItem();
            this.label6 = new System.Windows.Forms.Label();
            this.estado = new System.Windows.Forms.Label();
            this.registrarse = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBoxADAM.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.groupBoxUSRDR302.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.barracontrol.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 0;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(80, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 1;
            // 
            // groupBoxADAM
            // 
            this.groupBoxADAM.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxADAM.Controls.Add(this.tableLayoutPanel1);
            this.groupBoxADAM.Location = new System.Drawing.Point(53, 170);
            this.groupBoxADAM.Name = "groupBoxADAM";
            this.groupBoxADAM.Size = new System.Drawing.Size(358, 159);
            this.groupBoxADAM.TabIndex = 2;
            this.groupBoxADAM.TabStop = false;
            this.groupBoxADAM.Text = "Conexion con ADAM6050";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.txtModADAM, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.ADAMBUTTON, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtPuertoADAM, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtIpADAM, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(6, 19);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(346, 134);
            this.tableLayoutPanel1.TabIndex = 11;
            // 
            // txtModADAM
            // 
            this.txtModADAM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtModADAM.Location = new System.Drawing.Point(102, 72);
            this.txtModADAM.Name = "txtModADAM";
            this.txtModADAM.Size = new System.Drawing.Size(241, 20);
            this.txtModADAM.TabIndex = 7;
            // 
            // ADAMBUTTON
            // 
            this.ADAMBUTTON.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.ADAMBUTTON.Location = new System.Drawing.Point(241, 105);
            this.ADAMBUTTON.Name = "ADAMBUTTON";
            this.ADAMBUTTON.Size = new System.Drawing.Size(102, 22);
            this.ADAMBUTTON.TabIndex = 8;
            this.ADAMBUTTON.Text = "Enviar";
            this.ADAMBUTTON.UseVisualStyleBackColor = true;
            this.ADAMBUTTON.Click += new System.EventHandler(this.ADAMBUTTON_Click);
            // 
            // txtPuertoADAM
            // 
            this.txtPuertoADAM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPuertoADAM.Location = new System.Drawing.Point(102, 39);
            this.txtPuertoADAM.Name = "txtPuertoADAM";
            this.txtPuertoADAM.Size = new System.Drawing.Size(241, 20);
            this.txtPuertoADAM.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ip del dispositivo";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtIpADAM
            // 
            this.txtIpADAM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtIpADAM.BackColor = System.Drawing.SystemColors.Window;
            this.txtIpADAM.Location = new System.Drawing.Point(102, 6);
            this.txtIpADAM.Name = "txtIpADAM";
            this.txtIpADAM.Size = new System.Drawing.Size(241, 20);
            this.txtIpADAM.TabIndex = 3;
            this.txtIpADAM.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Puerto";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Comando Modbus";
            // 
            // groupBoxUSRDR302
            // 
            this.groupBoxUSRDR302.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBoxUSRDR302.Controls.Add(this.tableLayoutPanel2);
            this.groupBoxUSRDR302.Location = new System.Drawing.Point(527, 170);
            this.groupBoxUSRDR302.Name = "groupBoxUSRDR302";
            this.groupBoxUSRDR302.Size = new System.Drawing.Size(353, 159);
            this.groupBoxUSRDR302.TabIndex = 3;
            this.groupBoxUSRDR302.TabStop = false;
            this.groupBoxUSRDR302.Text = "Conexion con USR-DR302";
            this.groupBoxUSRDR302.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.Controls.Add(this.txtUSRmod, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label10, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.txtUSRIp, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtUSRport, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.USRDRBUTTON, 1, 3);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(6, 19);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(341, 134);
            this.tableLayoutPanel2.TabIndex = 12;
            // 
            // txtUSRmod
            // 
            this.txtUSRmod.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUSRmod.Location = new System.Drawing.Point(102, 72);
            this.txtUSRmod.Name = "txtUSRmod";
            this.txtUSRmod.Size = new System.Drawing.Size(236, 20);
            this.txtUSRmod.TabIndex = 7;
            this.txtUSRmod.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(3, 10);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(85, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Ip del dispositivo";
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(3, 43);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(38, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "Puerto";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(3, 76);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 13);
            this.label12.TabIndex = 5;
            this.label12.Text = "Comando Modbus";
            // 
            // txtUSRIp
            // 
            this.txtUSRIp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUSRIp.BackColor = System.Drawing.SystemColors.Window;
            this.txtUSRIp.Location = new System.Drawing.Point(102, 6);
            this.txtUSRIp.Name = "txtUSRIp";
            this.txtUSRIp.Size = new System.Drawing.Size(236, 20);
            this.txtUSRIp.TabIndex = 3;
            this.txtUSRIp.TextChanged += new System.EventHandler(this.txtUSRIp_TextChanged);
            // 
            // txtUSRport
            // 
            this.txtUSRport.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUSRport.Location = new System.Drawing.Point(102, 39);
            this.txtUSRport.Name = "txtUSRport";
            this.txtUSRport.Size = new System.Drawing.Size(236, 20);
            this.txtUSRport.TabIndex = 6;
            this.txtUSRport.TextChanged += new System.EventHandler(this.txtUSRport_TextChanged);
            // 
            // USRDRBUTTON
            // 
            this.USRDRBUTTON.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.USRDRBUTTON.Location = new System.Drawing.Point(236, 105);
            this.USRDRBUTTON.Name = "USRDRBUTTON";
            this.USRDRBUTTON.Size = new System.Drawing.Size(102, 22);
            this.USRDRBUTTON.TabIndex = 9;
            this.USRDRBUTTON.Text = "Enviar";
            this.USRDRBUTTON.UseVisualStyleBackColor = true;
            this.USRDRBUTTON.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(53, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(192, 135);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(336, 60);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(469, 39);
            this.label9.TabIndex = 6;
            this.label9.Text = "Controlador de Dispositivos";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // outputADAM
            // 
            this.outputADAM.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.outputADAM.BackColor = System.Drawing.Color.Gainsboro;
            this.outputADAM.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputADAM.Location = new System.Drawing.Point(6, 19);
            this.outputADAM.Name = "outputADAM";
            this.outputADAM.ReadOnly = true;
            this.outputADAM.Size = new System.Drawing.Size(342, 127);
            this.outputADAM.TabIndex = 9;
            this.outputADAM.Text = "";
            this.outputADAM.TextChanged += new System.EventHandler(this.outputADAM_TextChanged);
            // 
            // outputUSR
            // 
            this.outputUSR.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.outputUSR.BackColor = System.Drawing.Color.Gainsboro;
            this.outputUSR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outputUSR.Location = new System.Drawing.Point(6, 19);
            this.outputUSR.Name = "outputUSR";
            this.outputUSR.ReadOnly = true;
            this.outputUSR.Size = new System.Drawing.Size(342, 127);
            this.outputUSR.TabIndex = 10;
            this.outputUSR.Text = "";
            this.outputUSR.TextChanged += new System.EventHandler(this.outputUSR_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox1.Controls.Add(this.outputADAM);
            this.groupBox1.Location = new System.Drawing.Point(53, 363);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(354, 152);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Historial de comandos";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox2.Controls.Add(this.outputUSR);
            this.groupBox2.Location = new System.Drawing.Point(527, 363);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(354, 152);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Historial de comandos";
            // 
            // barracontrol
            // 
            this.barracontrol.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.visyedit,
            this.login,
            this.registrarse});
            this.barracontrol.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.barracontrol.Location = new System.Drawing.Point(0, 0);
            this.barracontrol.Name = "barracontrol";
            this.barracontrol.Size = new System.Drawing.Size(910, 24);
            this.barracontrol.TabIndex = 14;
            this.barracontrol.Text = "menuStrip1";
            // 
            // visyedit
            // 
            this.visyedit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dispositivos,
            this.silos});
            this.visyedit.Name = "visyedit";
            this.visyedit.Size = new System.Drawing.Size(178, 20);
            this.visyedit.Text = "Visualizar y editar informacion";
            this.visyedit.Click += new System.EventHandler(this.visyedit_Click);
            // 
            // dispositivos
            // 
            this.dispositivos.Name = "dispositivos";
            this.dispositivos.Size = new System.Drawing.Size(137, 22);
            this.dispositivos.Text = "Dispositivos";
            this.dispositivos.Click += new System.EventHandler(this.dispositivos_Click);
            // 
            // silos
            // 
            this.silos.Name = "silos";
            this.silos.Size = new System.Drawing.Size(137, 22);
            this.silos.Text = "Silos";
            this.silos.Click += new System.EventHandler(this.silos_Click);
            // 
            // login
            // 
            this.login.Name = "login";
            this.login.Size = new System.Drawing.Size(88, 20);
            this.login.Text = "Iniciar Sesion";
            this.login.Click += new System.EventHandler(this.iniciarSecionToolStripMenuItem_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(716, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 24);
            this.label6.TabIndex = 15;
            this.label6.Text = "Sesion:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // estado
            // 
            this.estado.AutoSize = true;
            this.estado.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.estado.ForeColor = System.Drawing.Color.Red;
            this.estado.Location = new System.Drawing.Point(802, 9);
            this.estado.Name = "estado";
            this.estado.Size = new System.Drawing.Size(96, 24);
            this.estado.TabIndex = 16;
            this.estado.Text = "No activa";
            this.estado.Click += new System.EventHandler(this.label7_Click);
            // 
            // registrarse
            // 
            this.registrarse.Name = "registrarse";
            this.registrarse.Size = new System.Drawing.Size(76, 20);
            this.registrarse.Text = "Registrarse";
            this.registrarse.Click += new System.EventHandler(this.registrarseToolStripMenuItem_Click);
            // 
            // Control
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 527);
            this.Controls.Add(this.estado);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBoxUSRDR302);
            this.Controls.Add(this.groupBoxADAM);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.barracontrol);
            this.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::WindowsFormsApp1.Properties.Settings.Default, "IPE", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.DataBindings.Add(new System.Windows.Forms.Binding("Location", global::WindowsFormsApp1.Properties.Settings.Default, "sabe", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = global::WindowsFormsApp1.Properties.Settings.Default.sabe;
            this.MainMenuStrip = this.barracontrol;
            this.Name = "Control";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "";
            this.Text = global::WindowsFormsApp1.Properties.Settings.Default.IPE;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBoxADAM.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.groupBoxUSRDR302.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.barracontrol.ResumeLayout(false);
            this.barracontrol.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxADAM;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtIpADAM;
        private System.Windows.Forms.TextBox txtPuertoADAM;
        private System.Windows.Forms.TextBox txtModADAM;
        private System.Windows.Forms.GroupBox groupBoxUSRDR302;
        private System.Windows.Forms.TextBox txtUSRmod;
        private System.Windows.Forms.TextBox txtUSRport;
        private System.Windows.Forms.TextBox txtUSRIp;
        private System.Windows.Forms.Button ADAMBUTTON;
        private System.Windows.Forms.Button USRDRBUTTON;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.RichTextBox outputADAM;
        private System.Windows.Forms.RichTextBox outputUSR;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.MenuStrip barracontrol;
        private System.Windows.Forms.ToolStripMenuItem visyedit;
        private System.Windows.Forms.ToolStripMenuItem login;
        private System.Windows.Forms.ToolStripMenuItem dispositivos;
        private System.Windows.Forms.ToolStripMenuItem silos;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label estado;
        private System.Windows.Forms.ToolStripMenuItem registrarse;
    }
}


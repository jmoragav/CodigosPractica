﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace WindowsFormsApp1
{
    class ValidadorDisp
    {
        private string modelo;
        private string fabricante;
        private string ip;
        private string puerto;
        private string comando;

        public ValidadorDisp(String modelo, String fabricante, string ip, string puerto, string comando)
        {

            this.modelo = modelo;
            this.fabricante = fabricante;
            this.ip = ip;
            this.puerto = puerto;
            this.comando = comando;
        }

        public List<Object> validar()
        {
            bool final = true;
            String modelo_err = "";
            String fab_err = "";
            String ip_err = "";
            String port_err = "";
            String com_err = "";
            String regex_nomb = @"^[a-zA-Z0-9&._-]+$";



            List<Object> add_list = new List<object>();


            if (Regex.IsMatch(puerto, @"^\d+$"))
            {

                final = true && final;

            }

            else
            {

                port_err = "El puerto entregado no es valido, revise si uso un puerto numerico";

                add_list.Add(port_err);
                final = false;
            }

            if (IsValidateIP(ip))
            {

                final = true && final;


            }


            else
            {
                ip_err = "El ip entregado no es valido";
                final = false;
                add_list.Add(ip_err);
            }

             if (Regex.IsMatch(fabricante, regex_nomb))
            {

                final = true && final;

            }

            else
            {

                fab_err = "El nombre del fabricante entregado no es valido, revise si contiene algun caracter no valido";

                add_list.Add(fab_err);
                final = false;
            }


            if (Regex.IsMatch(modelo, regex_nomb))
            {

                final = true && final;

            }

            else
            {

                modelo_err = "El nombre del modelo entregado no es valido, revise si contiene algun caracter no valido";

                add_list.Add(modelo_err);
                final = false;
            }




            String patron_separado = @"(([A-Z0-9]){2} *){8}";
            String patron_junto = @"([A-Z0-9]){16}";
            Match m = Regex.Match(comando, patron_separado);
            Match m2 = Regex.Match(comando, patron_junto);
            if (m.Success && comando.Length == 23)
            {

                final = true && final;

            }

            else if (m2.Success && comando.Length == 16)
            {


                final = true && final;


            }


            else
            {

                com_err = "El comando ingreso no cumple con el formato adecuado" + '\n' + "Los formatos adecuados son los siguientes" + '\n' + "XX XX XX XX ..... " + '\n' + "XXXXXXXX ..... "
                    + '\n' + "Cada comando debe estar compuesto por 8 bytes";


                add_list.Add(com_err);
                final = false;
            }



            add_list.Add(final);

            return add_list;

        }






        public static bool IsValidateIP(string Address)
        {
            //Match pattern for IP address    
            string Pattern = @"^([1-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$";
            //Regular Expression object    
            Regex check = new Regex(Pattern);

            //check to make sure an ip address was provided    
            if (string.IsNullOrEmpty(Address))
                //returns false if IP is not provided    
                return false;
            else
                //Matching the pattern    
                return check.IsMatch(Address, 0);
        }




    }
}

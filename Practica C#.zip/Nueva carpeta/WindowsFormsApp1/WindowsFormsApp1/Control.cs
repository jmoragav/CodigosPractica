﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Net;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Net.Sockets;


namespace WindowsFormsApp1
{


 
        public partial class Control : Form, Observers_Login
    {
        private bool loged;

        public Control()
        {
            loged = false;
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {


            String ip = txtUSRIp.Text;
            String puerto = txtUSRport.Text;
            String comand = txtUSRmod.Text;
            Validator valid = new Validator(ip, puerto, comand, 1);

            List<Object> l = valid.validar();
            int last = l.Count;
            bool checkeo = (bool)l.ElementAt(last - 1);

            if (checkeo) { 




            int port = Convert.ToInt32(puerto);
            UsrDrSocket usrs = new UsrDrSocket(ip, port);

         

            try
            {
                usrs.connect();
                outputUSR.AppendText(Environment.NewLine + DateTime.Today + " " + "Conectando...");



              
                String comando_listo = "";
           
                if (comand.Length== 23)
                {
                    comando_listo = comand;
                   


                }

                else if (comand.Length == 16)
                {

                    var list = Enumerable
                      .Range(0, comand.Length / 2)
                     .Select(i => comand.Substring(i * 2, 2));

                    comando_listo = string.Join(" ", list);
                    


                }

                
                

                    usrs.SendData(comando_listo);
                    usrs.ReciveData();
                    outputUSR.AppendText(Environment.NewLine + DateTime.Today + " " + "Datos recibidos");
                    byte[] resp = usrs.respuesta;
                    int bytesRec = usrs.Numdatos;
                   
                    String outresp = "";
                    for (int b = 0; b < bytesRec; b++)
                    {
                        int dummy = Convert.ToInt32(resp[b]);
                        String c = xadecimal(dummy);
                        outresp = outresp + " " + c;
                    }
                    outputUSR.AppendText(Environment.NewLine + DateTime.Today + " " + outresp);


                    string[] val_sep = outresp.Split(' ');

                    string fun_code = val_sep[2];

                    if (fun_code == "04")
                    {

                        outputUSR.AppendText(Environment.NewLine + DateTime.Today + " " + "Los valores se interpretan como:");

                        int bytes_count = int.Parse(val_sep[3], System.Globalization.NumberStyles.HexNumber);
                        int counter = 4;
                        String fh = "";
                        String sh = "";
                        int[] results_inter = new int[1024];
                        int reference_res = 0;

                        for (int k = 0; k < bytes_count; k++)
                        {
                            if (counter % 2 != 0)
                            {
                                sh = val_sep[counter];
                                String dummy = fh + sh;
                                int numin = int.Parse(dummy, System.Globalization.NumberStyles.HexNumber);
                                results_inter[reference_res] = numin;
                                reference_res++;
                                counter++;
                                fh = "";
                                sh = "";
                            }

                            else
                            {
                                fh = val_sep[counter];

                                counter++;

                            }


                        }

                        String results_str = "";
                        for (int j = 0; j < reference_res; j++)
                        {



                            results_str = results_str + results_inter[j].ToString() + " ";




                        }

                        outputUSR.AppendText(Environment.NewLine + DateTime.Today + " " + results_str);



                    }
                




            }



            catch (ArgumentNullException )
            {
               
                    MessageBox.Show("Se ingreso un nulo", "Errores de Nulo",
                            MessageBoxButtons.OK, MessageBoxIcon.Error);
                    outputUSR.AppendText(Environment.NewLine + DateTime.Today + " " + "Conexión fallida");


                }
                catch (SocketException se)
            {

                    MessageBox.Show("Ocurrio un error a la hora de comunicarse con el dispositivo"+'\n'+se.ToString(), "Errores de conexion",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                    outputUSR.AppendText(Environment.NewLine + DateTime.Today + " " + "Conexión fallida");
                }



        }



            else
            {
                string error = "";


                for(int k=0; k<(l.Count -1);k++)
                {

                    error = error + l.ElementAt(k) + '\n';

                }
                MessageBox.Show(error, "Errores de validacion",
                          MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void ADAMBUTTON_Click(object sender, EventArgs e)
        {




            String[] rd_adrs = { "01", "02", "03", "04" };
            String ip = txtIpADAM.Text;
            String puerto = txtPuertoADAM.Text;
            String comand = txtModADAM.Text;


            Validator valid = new Validator(ip, puerto, comand, 0);

            List<Object> l = valid.validar();
            int last = l.Count;



            bool checkeo = (bool)l.ElementAt(last - 1);

            if (checkeo)
            {


                int port = Convert.ToInt32(puerto);
                AdamSocket ads = new AdamSocket(ip, port);

                try
                {

                    ads.connect();
                    outputADAM.AppendText(Environment.NewLine + DateTime.Today + " " + "Conectando...");


                    String comando_listo = "";

                    if (comand.Length == 35)
                    {
                        comando_listo = comand;



                    }

                    else if (comand.Length == 24)
                    {

                        var list = Enumerable
                          .Range(0, comand.Length / 2)
                         .Select(i => comand.Substring(i * 2, 2));

                        comando_listo = string.Join(" ", list);


                    }



                    ads.SendData(comando_listo);
                    ads.ReciveData();
                    outputADAM.AppendText(Environment.NewLine + DateTime.Today + " " + "Datos recibidos:");
                    byte[] resp = ads.respuesta;
                    int bytesRec = ads.Numdatos;
                    
                    String outresp = "";
                    for (int b = 0; b < bytesRec; b++)
                    {
                        int dummy = Convert.ToInt32(resp[b]);
                        String c = xadecimal(dummy);
                        outresp = outresp + " " + c;
                    }
                    outputADAM.AppendText(Environment.NewLine + DateTime.Today + " " + outresp);

                    string[] val_sep = outresp.Split(' ');

                    string fun_code = val_sep[8];

                    if (rd_adrs.Contains(fun_code))
                    {

                        outputADAM.AppendText(Environment.NewLine + DateTime.Today + " " + "Los valores se interpretan como:");

                        int bytes_count = int.Parse(val_sep[9], System.Globalization.NumberStyles.HexNumber);
                        int counter = 10;
                        String fh = "";
                        String sh = "";
                        int[] results_inter = new int[1024];
                        int reference_res = 0;

                        for (int k = 0; k < bytes_count; k++)
                        {
                            if (counter % 2 != 0)
                            {
                                sh = val_sep[counter];
                                String dummy = fh + sh;
                                int numin = int.Parse(dummy, System.Globalization.NumberStyles.HexNumber);
                                results_inter[reference_res] = numin;
                                reference_res++;
                                counter++;
                                fh = "";
                                sh = "";
                            }

                            else
                            {
                                fh = val_sep[counter];

                                counter++;

                            }


                        }

                        String results_str = "";
                        for (int j = 0; j < reference_res; j++)
                        {



                            results_str = results_str + results_inter[j].ToString() + " ";




                        }

                        outputADAM.AppendText(Environment.NewLine + DateTime.Today + " " + results_str);




                    }



                }

                catch (ArgumentNullException ane)
                {

                    MessageBox.Show("Se ingreso un nulo "+'\n'+ane.ToString(), "Errores de nulo",
                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                    outputADAM.AppendText(Environment.NewLine + DateTime.Today + " " + "Conexión fallida");

                }
                catch (SocketException se)
                {


                    MessageBox.Show("Error al conectarse al dispositivo " + '\n' + se.ToString(), "Errores de nulo",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);

                    outputADAM.AppendText(Environment.NewLine + DateTime.Today + " " + "Conexión fallida");
                }



            }



            else {
                string error = "";


                for (int k = 0; k < (l.Count - 1); k++)
                {

                    error = error + l.ElementAt(k) + '\n';

                }
                MessageBox.Show(error, "Errores de validacion",
                          MessageBoxButtons.OK, MessageBoxIcon.Exclamation);



            }
          
        }

        public static String xadecimal(int dec)
        {
            if (dec < 1) return "0";

            int hex = dec;
            string hexStr = string.Empty;

            while (dec > 0)
            {
                hex = dec % 16;

                if (hex < 10)
                    hexStr = hexStr.Insert(0, Convert.ToChar(hex + 48).ToString());
                else
                    hexStr = hexStr.Insert(0, Convert.ToChar(hex + 55).ToString());

                dec /= 16;
            }

            if (hexStr.Length == 1)
            {
                hexStr = "0" + hexStr;
            }
            return hexStr;
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void txtUSRIp_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtUSRport_TextChanged(object sender, EventArgs e)
        {

        }

        private void outputUSR_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void outputADAM_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form prueba = new Login();
            prueba.Show();


        }

        private void controladorToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        

        private void iniciarSecionToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (!loged)
            {
                Observable inicio_ses = new Login();
                inicio_ses.addObservers(this);
                inicio_ses.ShowDialog();
                

            }

            else {

                loged = false;
                login.Text = "Iniciar Sesion";
                estado.ForeColor = Color.Red;
                estado.Text = "No Activa";
                registrarse.Visible = true;
                registrarse.Enabled = true;


            }
        }

        private void visyedit_Click(object sender, EventArgs e)
        {

        }

        void Observers_Login.Logear()
        {
            loged = true;

            login.Text = "Cerrar Sesion";
            estado.ForeColor = Color.Green;
            estado.Text = "Activo";
            registrarse.Visible = false;
            registrarse.Enabled = false;

        }

        private void dispositivos_Click(object sender, EventArgs e)
        {
            if (!loged)
            {
                Form Dispositivo = new Dispositivos();

                Dispositivo.ShowDialog();
                

            }

            else {

                Form Dispositivo = new Dispositivos(loged);

                Dispositivo.ShowDialog();

            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void silos_Click(object sender, EventArgs e)
        {
            if (!loged)
            {
                Form Silos = new Silos();

                Silos.ShowDialog();


            }

            else
            {

                Form Silos = new Silos(loged);

                Silos.ShowDialog();

            }
        }

        private void registrarseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form Registro = new Registro();

            Registro.ShowDialog();
        }
    }






}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace WindowsFormsApp1
{
    class ValidadorSilos
    {
        private string nombre;
        private string ubicacion;
        private string valor_max;
        private string valor_min;

        public ValidadorSilos(String Nombre, String Ubicacion, string valor_max, string valor_min) {

            nombre = Nombre;
            ubicacion = Ubicacion;
            this.valor_max = valor_max;
            this.valor_min = valor_min;
        }

        public List<Object> validar()
        {
            bool final = true;
            String nombre_err = "";
            String ubic_err = "";
            String max_err = "";
            String min_err = "";
            String regex_nomub = @"^[a-zA-Z0-9&._-]+$";
            String regex_nums = @"^[0-9]*$";

            List<Object> add_list = new List<object>();


            if (Regex.IsMatch(nombre, regex_nomub))
            {

                final = true && final;

            }

            else
            {

                nombre_err = "El nombre del silo contiene algun caracter no valido";

                add_list.Add(nombre_err);
                final = false;
            }



            if (Regex.IsMatch(ubicacion, regex_nomub))
            {

                final = true && final;

            }

            else
            {

                ubic_err = "El nombre de la ubicación del silo contiene algun caracter no valido";

                add_list.Add(ubic_err);
                final = false;
            }


            


            if (Regex.IsMatch(valor_min, regex_nums))
            {

                final = true && final;

            }

            else
            {

                ubic_err = "El valor minimo del silo contiene algun caracter no numerico";

                add_list.Add(min_err);
                final = false;
            }

            if (Regex.IsMatch(valor_max, regex_nums))
            {

                final = true && final;

            }

            else
            {

                ubic_err = "El valor maximo del silo contiene algun caracter no numerico";

                add_list.Add(max_err);
                final = false;
            }




            add_list.Add(final);

            return add_list;

        }




    }
}

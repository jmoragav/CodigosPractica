﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace WindowsFormsApp2
{
    class Asker
    {
        private UsrDrSocket u_socket;



        private string u_com;
        public String U_com { get { return u_com; } set { u_com = value; } }
    

        public Asker(UsrDrSocket usr_sck,  String ucom)
        {

            u_socket = usr_sck;
     
            
            u_com = ucom;
        }




        public static List<Object> getRespuesta_Usr(UsrDrSocket usock, String com)
        {

            usock.connect();
            usock.SendData(com);
            usock.ReciveData();

            int num_datos = usock.Numdatos;
            byte[] resp = usock.respuesta;

            List<Object> lista_f = new List<Object>();

            lista_f.Add(num_datos);
            lista_f.Add(resp);

            return lista_f;

        }


       


        public static String xadecimal(int dec)
        {
            if (dec < 1) return "0";

            int hex = dec;
            string hexStr = string.Empty;

            while (dec > 0)
            {
                hex = dec % 16;

                if (hex < 10)
                    hexStr = hexStr.Insert(0, Convert.ToChar(hex + 48).ToString());
                else
                    hexStr = hexStr.Insert(0, Convert.ToChar(hex + 55).ToString());

                dec /= 16;
            }

            if (hexStr.Length == 1)
            {
                hexStr = "0" + hexStr;
            }
            return hexStr;
        }

        public static String procesarRespuesta(int ndatos, byte[] resp, int tipo_disp)
        {

            //tipo disp 0 = USR; 1 = ADAM
            String outresp = "";
            for (int b = 0; b < ndatos; b++)
            {
                int dummy = Convert.ToInt32(resp[b]);
                String c = xadecimal(dummy);
                outresp = outresp + " " + c;
            }



            string[] val_sep = outresp.Split(' ');

            int index_of_count = 0;
            int counter = 0;
            if (tipo_disp == 0) { index_of_count = 3; counter = index_of_count + 1; }
            else { index_of_count = 9; counter = index_of_count + 1; }



            int bytes_count = int.Parse(val_sep[index_of_count], System.Globalization.NumberStyles.HexNumber);

            String fh = "";
            String sh = "";
            int[] results_inter = new int[1024];
            int reference_res = 0;

            for (int k = 0; k < bytes_count; k++)
            {
                if (counter % 2 != 0)
                {
                    sh = val_sep[counter];
                    String dummy = fh + sh;
                    int numin = int.Parse(dummy, System.Globalization.NumberStyles.HexNumber);
                    results_inter[reference_res] = numin;
                    reference_res++;
                    counter++;
                    fh = "";
                    sh = "";
                }

                else
                {
                    fh = val_sep[counter];

                    counter++;

                }


            }

            String results_str = "";
            for (int j = 0; j < reference_res; j++)
            {



                results_str = results_str + results_inter[j].ToString() + " ";




            }

            return results_str;

        }





        public String getRespuestas() {


            List<Object> lista_usr = getRespuesta_Usr(u_socket, u_com);
      

            String respuesta_usr = procesarRespuesta((int)lista_usr.ElementAt(0), (byte[])lista_usr.ElementAt(1), 0);
 
       
            return respuesta_usr;
        }



    }

}

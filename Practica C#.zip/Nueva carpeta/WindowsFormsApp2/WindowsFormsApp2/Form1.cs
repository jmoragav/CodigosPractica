﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace WindowsFormsApp2
{
    public partial class DataL : Form
    {
        private Timer timer1;
     
        private bool exis;
        private bool started;
        private string modbus_comando;
        private string ip_disp;
        private int puerto_disp;
        private int id_sil;
        private SqlConnection cnn;
        private string default_com;

        
  

        public DataL()
        {
            InitializeComponent();
            
      
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, EventArgs e)
        {
            

            
           

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
         
            exis = File.Exists(@"C:\jmoraga\test.txt");
            started = false;
            string connetionString = @"Data Source=NEP-DC-F02;Initial Catalog=SilosPractica ;User ID=practica;Password=practica";
            cnn = new SqlConnection(connetionString);



            
        }


        private void Form1_Shown(object sender, EventArgs e)
        {

            SqlCommand command_1;
            SqlDataReader datar_1;
            String sql;
            cnn.Open();

            sql = "SELECT id_silo,nombre FROM Silo WHERE estado LIKE 'activo%'";
            command_1 = new SqlCommand(sql, cnn);

            datar_1 = command_1.ExecuteReader();


            silosbox.Items.Clear();
            while (datar_1.Read())
            {
                string mod_id = datar_1.GetValue(0) + "-" + datar_1.GetValue(1);
                silosbox.Items.Add(mod_id);


            }
            cnn.Close();

            consulta.Text = "Intervalo de Registro" + '\n' + "(En segundos)";
            timer1 = new Timer();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void txtTiempo_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtIpADAM_TextChanged(object sender, EventArgs e)
        {
            if (
                !started)
            {
                if (!string.IsNullOrWhiteSpace(txtPuerto.Text))
                    crearCom();

                else {

                    modbustxt.Text = default_com;
                }
            }
        }

        public void InitTimer()
        {

            timer1.Tick += new EventHandler(Registrar);
         
            timer1.Interval = Convert.ToInt32(tiempo.Value)*1000; // in miliseconds
            timer1.Start();
        }

        


        public void crearCom() {

            try
            {
                string comando_fake = "01 04 00 XX 00 01 CR CR";


                String puerto_us = txtPuerto.Text;
                String final_puerto = "";
                if (puerto_us.Length == 1) { final_puerto = puerto_us.Insert(0, "0"); }
                else { final_puerto = puerto_us; }

                String almost_c = comando_fake.Replace("XX", final_puerto);

                String comand_no_cr = almost_c.Substring(0, 17);

                byte[] frame = FormarModbus(comand_no_cr);
                int crc = ModRTU_CRC(frame, frame.Length);

                String checksum_raw = xadecimal(crc);
                String checksum = "";
                if (checksum_raw.Length == 3)
                {
                    String Higb = checksum_raw.Substring(1, 2);
                    String Lowb = checksum_raw.Substring(0, 1);
                    checksum = Higb.Insert(2, "  0" + Lowb);




                }


                else
                {

                    String Higb = checksum_raw.Substring(2, 2);
                    String Lowb = checksum_raw.Substring(0, 2);
                    checksum = Higb.Insert(2, " " + Lowb);
                }



                String comando = almost_c.Replace("CR CR", checksum);
                modbus_comando = comando;
            }

            catch (Exception e)
            {
                MessageBox.Show(e.ToString(), "Error",
                     MessageBoxButtons.OK, MessageBoxIcon.Error);
            }





            if (!string.IsNullOrWhiteSpace(silosbox.Text)) {

                modbustxt.Text = modbus_comando;

            }
        }



        public void Registrar(object sender, EventArgs e)
        {


            UsrDrSocket us = new UsrDrSocket(ip_disp, puerto_disp);
          

            

            Asker ask = new Asker(us, modbus_comando);
            String registro = ask.getRespuestas();
            String date = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            
            string linea = date+" " + registro +'\n';

            int regist_int = Convert.ToInt32(registro);

            SqlCommand cmd = new SqlCommand("[dbo].[pkg_Registro.InsertarDatos]", cnn);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(
                    new SqlParameter("@IdSilo", id_sil));
            cmd.Parameters.Add(
                    new SqlParameter("@Valor", regist_int));
    


            cnn.Open();
            cmd.ExecuteNonQuery();
            cnn.Close();

            if (exis)
            {
                using (StreamWriter sw = new StreamWriter(@"C:\jmoraga\test.txt", true))
                {


                    sw.WriteLine(linea);
                 

                }
            }
            else
            {

                using (StreamWriter sw = new StreamWriter(@"C:\jmoraga\test.txt"))
                {


                    sw.WriteLine(linea);
                
                    exis = true;

                }

            }





        }

        private void button1_Click(object sender, EventArgs e)
        {
            String selec = silosbox.Text;
            if (!String.IsNullOrEmpty(selec))
            {


                if (
                !started)
                {


                    started = true;
                }

                String puerto = txtPuerto.Text;


                String testport = @"^([0-9]{1,4}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])$";
                Match m = Regex.Match(puerto, testport, RegexOptions.IgnoreCase);
                if (m.Success || String.IsNullOrEmpty(puerto))
                {

                    if (String.IsNullOrEmpty(puerto)) {

                        modbus_comando = default_com;
                        modbustxt.Text = modbus_comando;

                    }


                    estado.Text = "Activo";

                    estado.ForeColor = Color.Green;


                    InitTimer();



                }

                else
                {

                    MessageBox.Show("El puerto entregado es invalido", "Erro de puerto",
                                     MessageBoxButtons.OK, MessageBoxIcon.Error);

                }

            }

            else {
                MessageBox.Show("Porfavor seleccione un silo", "Erro de Silo",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }




        public static byte[] FormarModbus(String mensaje)
        {
            string[] valores = mensaje.Split(' ');

            int largo = valores.Length;
            byte[] frame = new byte[largo];

            for (int i = 0; i < largo; i++)
            {
                int numin = int.Parse(valores[i], System.Globalization.NumberStyles.HexNumber);
                String dummy = numin.ToString();
                frame[i] = Convert.ToByte(dummy);

            }


            return frame;

        }



        public static UInt16 ModRTU_CRC(byte[] buf, int len)
        {
            UInt16 crc = 0xFFFF;

            for (int pos = 0; pos < len; pos++)
            {
                crc ^= (UInt16)buf[pos];          // XOR byte into least sig. byte of crc

                for (int i = 8; i != 0; i--)
                {    // Loop over each bit
                    if ((crc & 0x0001) != 0)
                    {      // If the LSB is set
                        crc >>= 1;                    // Shift right and XOR 0xA001
                        crc ^= 0xA001;
                    }
                    else                            // Else LSB is not set
                        crc >>= 1;                    // Just shift right
                }
            }
            // Note, this number has low and high bytes swapped, so use it accordingly (or swap bytes)
            return crc;
        }


        public static String xadecimal(int dec)
        {
            if (dec < 1) return "0";

            int hex = dec;
            string hexStr = string.Empty;

            while (dec > 0)
            {
                hex = dec % 16;

                if (hex < 10)
                    hexStr = hexStr.Insert(0, Convert.ToChar(hex + 48).ToString());
                else
                    hexStr = hexStr.Insert(0, Convert.ToChar(hex + 55).ToString());

                dec /= 16;
            }

            if (hexStr.Length == 1)
            {
                hexStr = "0" + hexStr;
            }
            return hexStr;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            String selec = silosbox.Text;
            if (!String.IsNullOrEmpty(selec))
            {


                estado.Text = "Inactivo";

                estado.ForeColor = Color.Red;

                if (started)
                {

                    timer1.Stop();

                    started = false;
                }

                else {

                    MessageBox.Show("No se a comenzado a registrar todavia", "Error",
                                   MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }

            else {

                MessageBox.Show("Porfavor seleccione un silo", "Error de Silo",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            }



            

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void estado_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter_1(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint_1(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }



        private void silosbox_SelectedIndexChanged(object sender,
        System.EventArgs e)
        {

            String selec = silosbox.Text;
            if (!String.IsNullOrEmpty(selec)) {

                String[] dummy = selec.Split('-');

                string id_silo = dummy[0];
                SqlCommand cmd = new SqlCommand("[dbo].[pkg_Silo.DatosDispositivo]", cnn);


                id_sil = Convert.ToInt32(id_silo);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(
                        new SqlParameter("@IdSilo", id_silo));
                cnn.Open();

                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                modelotxt.Text = (String )reader.GetValue(0);
                iptxt.Text = (String)reader.GetValue(1);
                puertotxt.Text = reader.GetValue(2).ToString();
                default_com= (String)reader.GetValue(3);
                modbustxt.Text = modbus_comando;


                ip_disp= (String)reader.GetValue(1); 
                puerto_disp = (Int32) reader.GetValue(2);
           
                cnn.Close();
            }

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void tiempo_ValueChanged(object sender, EventArgs e)
        {
            try
            {

                timer1.Interval = Convert.ToInt32(tiempo.Value) * 1000;
            }
            catch (ArgumentOutOfRangeException ex) {

                MessageBox.Show("Ingrese un numero positivo", "Error",
                     MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }



        private void changeLight()
        {


        }
    }
}
